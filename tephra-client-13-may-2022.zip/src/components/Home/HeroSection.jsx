import React from "react";

const HeroSection = () => {
	return <div>kek</div>;
};

export default HeroSection;
