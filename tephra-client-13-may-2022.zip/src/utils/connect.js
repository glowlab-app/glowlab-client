// import { Provider, Signer } from "@reef-defi/evm-provider";
// // import { WsProvider } from "@polkadot/rpc-provider";
// import { WsProvider } from "@polkadot/api";
// // import { options } from "@reef-defi/api";
// import {
// 	web3Accounts,
// 	web3Enable,
// 	web3FromSource,
// } from "@reef-defi/extension-dapp";
// import { stringToHex } from "@reef-defi/util";
// import axios from "axios";
// import { getBackend, getRPC } from "./network";
// // const WS_URL = 'wss://rpc-testnet.reefscan.com/ws';

// let provider;

// const Init = async () => {
// 	await web3Enable("Sqwid");
// 	return await web3Accounts();
// };

// const Connect = async account => {
// 	const injector = await web3FromSource(account.meta.source);

// 	const signRaw = injector?.signer?.signRaw;

// 	const { signer } = await Interact(account.address);

// 	if (!!signRaw) {
// 		if (!(await signer.isClaimed())) {
// 			return {
// 				evmClaimed: false,
// 				signer,
// 			};
// 		}
// 		let res = await axios.get(
// 			`${getBackend()}/nonce?address=${account.address}`
// 		);
// 		let { nonce } = res.data;

// 		const sres = await signRaw({
// 			address: account.address,
// 			data: stringToHex(nonce),
// 			type: "bytes",
// 		});

// 		const { signature } = sres;
// 		try {
// 			res = await axios(`${getBackend()}/auth`, {
// 				method: "POST",
// 				headers: {
// 					"Content-Type": "application/json",
// 				},
// 				data: JSON.stringify({
// 					address: account.address,
// 					signature: signature,
// 					evmAddress: await signer.getAddress(),
// 				}),
// 			});
// 		} catch (err) {
// 			// handle err like a normal person 👍
// 		}

// 		let json = res.data;

// 		if (json.status === "success") {
// 			localStorage.removeItem("collections");
// 			let jwts = localStorage.getItem("tokens");
// 			jwts = jwts ? JSON.parse(jwts) : [];

// 			let item = jwts.find(jwt => jwt.address === account.address);
// 			if (item) {
// 				item.token = json.token;
// 			} else {
// 				jwts.push({
// 					name: account.meta.name,
// 					address: account.address,
// 					token: json.token,
// 				});
// 			}

// 			localStorage.setItem("tokens", JSON.stringify(jwts));

// 			return {
// 				evmClaimed: await signer.isClaimed(),
// 				signer,
// 			};
// 		}
// 	}
// };

// const Interact = async (address = null) => {
// 	if (!address)
// 		address = JSON.parse(localStorage.getItem("auth"))?.auth.address;
// 	const allInjected = await web3Enable("Sqwid");
// 	const injected = allInjected[0].signer;
// 	if (!provider)
// 		provider = new Provider({
// 			provider: new WsProvider(getRPC()),
// 			types: {
// 				AccountInfo: "AccountInfoWithTripleRefCount",
// 			},
// 		});
// 	await provider.api.isReady;

// 	const signer = new Signer(provider, address, injected);

// 	return {
// 		signer,
// 		provider,
// 	};
// };

// const GetProvider = async () => {
// 	if (!provider)
// 		provider = new Provider({
// 			provider: new WsProvider(getRPC()),
// 			types: {
// 				AccountInfo: "AccountInfoWithTripleRefCount",
// 			},
// 		});
// 	await provider.api.isReady;
// 	return provider;
// };

// export { Connect, Init, Interact, GetProvider };

import Web3 from "web3";
import axios from "axios";
import { getBackend, getRPC } from "./network";

import { PolyjuiceHttpProvider, PolyjuiceAccounts } from "@polyjuice-provider/web3";
import { AddressTranslator } from "nervos-godwoken-integration";


const addressTranslator = new AddressTranslator ();

let provider;
let signer;
let web3;
let account = {
    ethAddress: null,
    polyjuiceAddress: null
};

const polyjuiceConfig = {
    web3Url: getRPC (), 
};

const Init = async () => {
    if (account.ethAddress && signer) return account;
    provider = new PolyjuiceHttpProvider(
        getRPC (),
        polyjuiceConfig,
    );
    web3 = new Web3 (provider);

    signer = new PolyjuiceAccounts (polyjuiceConfig, provider);
    // console.log (signer);
    // try {
    //     await signer.godwoker.init ();
    // } catch (err) {
    //     console.log (err);
    // }

    try {
        // Request account access if needed
        let acc = await window.ethereum.request ({ method: 'eth_requestAccounts' });
        account.ethAddress = acc [0];
        account.polyjuiceAddress = addressTranslator.ethAddressToGodwokenShortAddress (acc [0]);
        console.log (account);
        return account;
    } catch (error) {
        // User denied account access...
        return null;
    }
}

const Connect = async () => {
    if (!account.ethAddress) await Init ();

    let res = await axios.get(`${getBackend ()}/nonce?address=${account.ethAddress}`);
    let { nonce } = res.data;

    console.log (nonce);
    let msg = web3.utils.fromUtf8 (`Sign this message to authenticate on the Tephra marketplace: ${nonce}`);
    let signature = await window.ethereum.request ({ method: 'personal_sign', params: [msg, account.ethAddress] });
    console.log ([msg, account.ethAddress]);
    try {
        res = await axios (`${getBackend ()}/auth`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            data: JSON.stringify ({
                address: account.ethAddress,
                signature: signature,
                polyjuiceAddress: account.polyjuiceAddress,
            })
        });
    } catch(err) {
        // handle err like a normal person 👍
    }

    let json = res.data;

    if (json.status === 'success') {
        localStorage.removeItem ('collections');
        let jwts = localStorage.getItem ('tokens');
        jwts = jwts ? JSON.parse (jwts) : [];

        let item = jwts.find (jwt => jwt.address === account.address);
        if (item) {
            item.token = json.token;
        } else {
            jwts.push ({
                name: account.ethAddress,
                address: account.ethAddress,
                polyjuiceAddress: account.polyjuiceAddress,
                token: json.token
            });
        }

        localStorage.setItem ('tokens', JSON.stringify (jwts));

        // return {
        //     jwt: res.data.token
        // }
        return {
            signer,
            account
        }
    }

    // return true;
}

const Interact = async () => {
    // if (!address) address = JSON.parse (localStorage.getItem ("auth"))?.auth.address;
    // const allInjected = await web3Enable ('Sqwid');
    // const injected = allInjected[0].signer;
    // if (!provider) provider = new Provider ({
    //     provider: new WsProvider (getRPC ())
    // });
    // await provider.api.isReady;

    // const signer = new Signer (provider, address, injected);
    if (!account.ethAddress) await Init ();

    return {
        signer,
        provider
    }
}

const GetProvider = async () => {
    // if (!provider) provider = new Provider ({
    //     provider: new WsProvider (getRPC ())
    // });
    // await provider.api.isReady;
    // return provider;
	return null;
}

export { Connect, Init, Interact, GetProvider };