export const getAvatarFromId = id =>
	`https://avatars.dicebear.com/api/identicon/${encodeURI(id)}.svg`;
