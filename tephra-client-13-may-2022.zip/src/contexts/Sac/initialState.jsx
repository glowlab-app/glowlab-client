export const initialState = {
	id: "",
	name: "",
	image: "",
	price: "",
	wave: "",
	totalSellers: "",
	topSellers: [],
	accumulated: "",
	date: "",
	percent: "",
	redeemCards: [],
};
