import { createContext } from "react";
import { initialState } from "./initialState";

const SacContext = createContext(initialState);

export default SacContext;
