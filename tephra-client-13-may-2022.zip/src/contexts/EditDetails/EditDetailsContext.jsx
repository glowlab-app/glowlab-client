import { createContext } from "react";
import { initialState } from "./initialState";

const EditDetailsContext = createContext(initialState);

export default EditDetailsContext;
