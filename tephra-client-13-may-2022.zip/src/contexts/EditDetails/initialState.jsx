export const initialState = {
	name: "",
	description: "",
};
