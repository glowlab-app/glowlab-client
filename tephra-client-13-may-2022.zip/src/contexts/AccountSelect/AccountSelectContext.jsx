import { createContext } from "react";
import { initialState } from "./initialState";
const AccountSelectContext = createContext(initialState);

export default AccountSelectContext;
