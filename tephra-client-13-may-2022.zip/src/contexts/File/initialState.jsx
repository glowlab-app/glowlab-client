export const initialState = {
	files: {
		name: "",
		description: "",
		royalty: "",
		copies: "",
		properties: "",
		collection: "",
		collectionName: "",
	},
	fileData: {
		file: null,
		coverFile: null,
	},
};
